part1.java will encrypt a text file into a mode that the user picks.
when the encryption option is chosen it will produce a encrypted output that is named by the user or will be generated
by the method. When decryption option is chosen the same will happen but an input file, key and initialisation vector
must be provided. Without these the decryption will not work. I have edited Erik Costlow's code to work with my
application.