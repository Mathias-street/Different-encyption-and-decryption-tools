The results.csv file has 5 different things that it has measured. It records:
- what text it has used,
- which mode of cipher has been used, 
- size of the key,
- if encryption or decryption has taken place,
- time taken to complete the process.

The first row is the header which categorises each column.

